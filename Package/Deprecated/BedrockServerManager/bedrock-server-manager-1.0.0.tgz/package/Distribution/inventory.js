/**
 * Read-only inventory, validation, activation inspection and addon selection.
 *
 * @file inventory.ts
 */
import { Effect, FileSystem, Path } from "effect";
import { object, parseManifest, sameVersion, uuid, version, versionText } from "./manifest.js";
import { resolveServer, resolveWorld } from "./server.js";
import { readRegistry } from "./registry.js";
const errorDiagnostic = (code, location, message) => ({ code, location, message, severity: "error" });
/** Test real paths rather than string prefixes, including symlinked descendants. */
const contained = (parent, child) => Effect.gen(function* () {
    const path = yield* Path.Path;
    const fs = yield* FileSystem.FileSystem;
    const relative = path.relative(yield* fs.realPath(parent), yield* fs.realPath(child));
    return relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative);
});
const inspectPack = (server, relativeLocation, scope, kind, diagnostics) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const location = path.join(server, ...relativeLocation.split("/"));
    const pack = {
        activation: "disabled", identity: null, kind, location, manifest: null, relativeLocation, scope
    };
    let rawManifest = null;
    const inspected = yield* Effect.result(Effect.gen(function* () {
        if (!(yield* contained(server, location))) {
            return yield* Effect.fail(new Error("Pack directory resolves outside the server."));
        }
        const file = path.join(location, "manifest.json");
        if (!(yield* contained(location, file))) {
            return yield* Effect.fail(new Error("Manifest resolves outside its pack directory."));
        }
        const text = yield* fs.readFileString(file);
        const raw = yield* Effect.try({
            catch: (error) => new Error(`Invalid manifest JSON: ${String(error)}`),
            try: () => JSON.parse(text)
        });
        rawManifest = object(raw) ? raw : null;
        const identity = yield* Effect.try({
            catch: (error) => error instanceof Error ? error : new Error(String(error)),
            try: () => parseManifest(raw)
        });
        return { identity, raw };
    }));
    if (inspected._tag === "Failure") {
        diagnostics.push(errorDiagnostic("invalid-manifest", location, String(inspected.failure)));
        return { ...pack, manifest: rawManifest };
    }
    const identity = inspected.success.identity;
    const result = { ...pack, identity, manifest: identity.raw };
    if (identity.kind !== kind) {
        diagnostics.push(errorDiagnostic("wrong-pack-directory", location, `Manifest declares ${identity.kind} content in the ${kind} pack directory.`));
    }
    for (const entry of identity.scripts) {
        const safe = !path.isAbsolute(entry) && !/[\\:\0]/.test(entry) &&
            !entry.split("/").some((part) => part === ".." || part === "");
        if (!safe) {
            diagnostics.push(errorDiagnostic("unsafe-script-entry", location, `Unsafe script entry: ${entry}`));
            continue;
        }
        const script = path.join(location, entry);
        const checked = yield* Effect.result(Effect.gen(function* () {
            const info = yield* fs.stat(script);
            return info.type === "File" && (yield* contained(location, script));
        }));
        if (checked._tag === "Failure" || !checked.success) {
            diagnostics.push(errorDiagnostic("missing-script-entry", location, `Script entry must be an existing file inside the pack: ${entry}`));
        }
    }
    return result;
});
const activationFile = (directory, kind, diagnostics) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const file = path.join(directory, `world_${kind}_packs.json`);
    if (!(yield* fs.exists(file))) {
        return [];
    }
    const checked = yield* Effect.result(Effect.gen(function* () {
        if (!(yield* contained(directory, file))) {
            return yield* Effect.fail(new Error("Activation file resolves outside the world directory."));
        }
        const text = yield* fs.readFileString(file);
        return yield* Effect.try({
            catch: (error) => new Error(String(error)),
            try: () => {
                const raw = JSON.parse(text);
                if (!Array.isArray(raw)) {
                    throw new Error("Expected an activation array.");
                }
                return raw.map((entry, index) => {
                    if (!object(entry) || !uuid(entry.pack_id) || !version(entry.version)) {
                        throw new Error(`Invalid activation entry at index ${index}.`);
                    }
                    return { pack_id: entry.pack_id.toLowerCase(), version: entry.version };
                });
            }
        });
    }));
    if (checked._tag === "Failure") {
        diagnostics.push(errorDiagnostic("invalid-activation-file", file, String(checked.failure)));
        return null;
    }
    return checked.success;
});
const validatePacks = (packs, diagnostics) => {
    const identities = new Map();
    for (const pack of packs) {
        if (!pack.identity) {
            continue;
        }
        for (const id of [pack.identity.uuid, ...pack.identity.moduleUuids]) {
            identities.set(id, [...(identities.get(id) ?? []), pack]);
        }
    }
    for (const [id, matches] of identities) {
        if (matches.length < 2) {
            continue;
        }
        for (const pack of matches) {
            diagnostics.push(errorDiagnostic("duplicate-identity", pack.location, `UUID ${id} appears in: ${matches.map((item) => item.location).join(", ")}`));
        }
    }
    for (const pack of packs) {
        for (const dependency of pack.identity?.dependencies ?? []) {
            if (dependency.module_name) {
                diagnostics.push({
                    code: "scripting-api", location: pack.location,
                    message: `${dependency.module_name}@${versionText(dependency.version)} ` +
                        "(runtime requirement)",
                    severity: "info"
                });
                continue;
            }
            const matches = packs.filter((item) => item.identity?.uuid === dependency.uuid);
            if (matches.length !== 1) {
                const code = matches.length ? "ambiguous-dependency" : "missing-dependency";
                diagnostics.push(errorDiagnostic(code, pack.location, `Dependency ${dependency.uuid} needs exactly one installed pack.`));
            }
            else if (!sameVersion(matches[0].identity.version, dependency.version)) {
                diagnostics.push(errorDiagnostic("dependency-version", pack.location, `Dependency ${dependency.uuid} requires ${versionText(dependency.version)}; installed ` +
                    `${versionText(matches[0].identity.version)}.`));
            }
        }
    }
};
const markActivation = (packs, kind, entries) => {
    for (const pack of packs.filter((item) => item.kind === kind)) {
        if (entries === null) {
            pack.activation = "unknown";
            continue;
        }
        const matches = entries.filter((entry) => entry.pack_id === pack.identity?.uuid);
        if (!matches.length) {
            continue;
        }
        const duplicates = packs.filter((item) => item.identity?.uuid === pack.identity?.uuid);
        pack.activation = matches.length === 1 && duplicates.length === 1 && pack.identity?.kind === kind &&
            sameVersion(matches[0].version, pack.identity.version) ? "enabled" : "invalid";
    }
};
const inspectActivation = (packs, kind, entries, directory, diagnostics) => {
    const seen = new Set();
    for (const entry of entries ?? []) {
        if (seen.has(entry.pack_id)) {
            diagnostics.push(errorDiagnostic("duplicate-activation", directory, `Duplicate ${kind} activation: ${entry.pack_id}`));
        }
        seen.add(entry.pack_id);
        const matches = packs.filter((pack) => pack.identity?.uuid === entry.pack_id &&
            pack.kind === kind && pack.identity.kind === kind);
        if (matches.length !== 1 || !sameVersion(matches[0].identity.version, entry.version)) {
            diagnostics.push(errorDiagnostic("invalid-activation-reference", directory, `${kind} reference ${entry.pack_id}@${versionText(entry.version)} ` +
                "has no unique matching pack."));
        }
    }
    const enabled = packs.filter((item) => item.activation === "enabled" && item.kind === kind);
    for (const pack of enabled) {
        for (const dependency of pack.identity?.dependencies ?? []) {
            if (!dependency.uuid) {
                continue;
            }
            const matches = packs.filter((item) => item.identity?.uuid === dependency.uuid);
            // Other pack kinds are marked before this routine's dependency pass by discoverInventory.
            if (matches.length === 1 && matches[0].activation !== "enabled") {
                diagnostics.push(errorDiagnostic("inactive-dependency", pack.location, `Enabled pack requires inactive dependency ${dependency.uuid}.`));
            }
        }
    }
};
/** Discover shared and selected-world pack roots and reconcile registered membership. */
const discoverInventory = (context, options = {}) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const server = yield* resolveServer(context, options.server);
    const world = yield* resolveWorld(context, server, options.world);
    const registry = yield* readRegistry(server);
    const diagnostics = [];
    const packs = [];
    for (const scope of ["shared", "world"]) {
        for (const kind of ["behavior", "resource"]) {
            const prefix = scope === "shared" ? "" : `worlds/${world.name}/`;
            const relativeRoot = `${prefix}${kind}_packs`;
            const root = path.join(server, ...relativeRoot.split("/"));
            if (!(yield* fs.exists(root))) {
                continue;
            }
            const checked = yield* Effect.result(Effect.gen(function* () {
                if (!(yield* contained(server, root))) {
                    return yield* Effect.fail(new Error("Pack root resolves outside the server."));
                }
                return yield* fs.readDirectory(root);
            }));
            if (checked._tag === "Failure") {
                diagnostics.push(errorDiagnostic("unreadable-pack-root", root, String(checked.failure)));
                continue;
            }
            for (const name of checked.success.sort()) {
                const location = path.join(root, name);
                const info = yield* Effect.result(fs.stat(location));
                if (info._tag === "Failure") {
                    diagnostics.push(errorDiagnostic("unreadable-pack", location, String(info.failure)));
                }
                else if (info.success.type === "Directory") {
                    packs.push(yield* inspectPack(server, `${relativeRoot}/${name}`, scope, kind, diagnostics));
                }
            }
        }
    }
    validatePacks(packs, diagnostics);
    const behavior = yield* activationFile(world.directory, "behavior", diagnostics);
    const resource = yield* activationFile(world.directory, "resource", diagnostics);
    // Mark both kinds before checking cross-kind dependencies.
    markActivation(packs, "behavior", behavior);
    markActivation(packs, "resource", resource);
    inspectActivation(packs, "behavior", behavior, world.directory, diagnostics);
    inspectActivation(packs, "resource", resource, world.directory, diagnostics);
    const addons = [];
    const claimed = new Set();
    const equalLocation = (left, right) => path.sep === "\\"
        ? left.toLowerCase() === right.toLowerCase() : left === right;
    for (const bundle of registry.bundles) {
        const members = [];
        let visible = false;
        for (const member of bundle.packs) {
            if (member.location.startsWith("worlds/") &&
                !member.location.startsWith(`worlds/${world.name}/`)) {
                continue;
            }
            visible = true;
            const pack = packs.find((item) => equalLocation(item.relativeLocation, member.location));
            if (!pack) {
                diagnostics.push(errorDiagnostic("missing-registered-pack", path.join(server, member.location), `Bundle ${bundle.id} is missing registered pack ${member.uuid}.`));
                continue;
            }
            claimed.add(pack);
            members.push(pack);
            if (pack.identity?.uuid !== member.uuid) {
                diagnostics.push(errorDiagnostic("registry-identity-mismatch", pack.location, `Bundle ${bundle.id} records UUID ${member.uuid}; ` +
                    "installed manifest differs or is invalid."));
            }
        }
        if (visible) {
            addons.push({ id: bundle.id, members, name: bundle.name, registered: true,
                registeredMembers: bundle.packs, source: bundle.source });
        }
    }
    for (const pack of packs) {
        if (claimed.has(pack)) {
            continue;
        }
        addons.push({
            id: `unregistered:${pack.relativeLocation}`, members: [pack],
            name: pack.identity?.name ?? path.basename(pack.location), registered: false,
            registeredMembers: [], source: null
        });
    }
    return { addons, diagnostics, server, world };
});
const scopedAddons = (inventory, scope) => scope === undefined
    ? inventory.addons : inventory.addons.filter((addon) => addon.members.some((pack) => pack.scope === scope) || addon.registeredMembers.some((member) => scope === "world"
    ? member.location.startsWith(`worlds/${inventory.world.name}/`)
    : !member.location.startsWith("worlds/")));
/** Every selector form shares ambiguity detection, including names that collide with IDs. */
const selectAddon = (inventory, selector, scope) => Effect.gen(function* () {
    const matches = scopedAddons(inventory, scope).filter((addon) => addon.id === selector ||
        addon.name === selector || addon.members.some((pack) => pack.identity?.uuid === selector.toLowerCase() || pack.identity?.name === selector) ||
        addon.registeredMembers.some((member) => member.uuid === selector.toLowerCase()));
    if (matches.length === 1) {
        return matches[0];
    }
    return yield* Effect.fail(new Error(matches.length
        ? `Ambiguous addon "${selector}". Candidates: ${matches.map((addon) => `${addon.id} (${addon.name})`).join(", ")}`
        : `No addon matches "${selector}". Use bds addon list to inspect installed IDs and names.`));
});
export { discoverInventory, scopedAddons, selectAddon };
