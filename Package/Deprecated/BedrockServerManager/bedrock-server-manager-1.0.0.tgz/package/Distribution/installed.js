/**
 * Server-wide identity preflight for mutations, independent of a selected world.
 *
 * @file installed.ts
 */
import { Effect, FileSystem, Path } from "effect";
import { portableName, rejectLinks } from "./safety.js";
import { parseManifest } from "./manifest.js";
/** Inspect every world's pack roots so conflicting ownership cannot hide outside the selection. */
const scanInstalled = (server) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const worlds = path.join(server, "worlds");
    const owners = [null];
    if (yield* fs.exists(worlds)) {
        yield* rejectLinks(worlds);
        for (const name of yield* fs.readDirectory(worlds)) {
            const directory = path.join(worlds, name);
            yield* rejectLinks(directory);
            if ((yield* fs.stat(directory)).type === "Directory") {
                owners.push(name);
            }
        }
    }
    const packs = [];
    const seen = new Set();
    for (const world of owners) {
        for (const kind of ["behavior", "resource"]) {
            const root = world === null ? path.join(server, `${kind}_packs`)
                : path.join(worlds, world, `${kind}_packs`);
            yield* rejectLinks(root, true);
            if (!(yield* fs.exists(root))) {
                continue;
            }
            for (const folder of (yield* fs.readDirectory(root)).sort()) {
                const location = path.join(root, folder);
                yield* rejectLinks(location);
                if ((yield* fs.stat(location)).type !== "Directory") {
                    continue;
                }
                const file = path.join(location, "manifest.json");
                yield* rejectLinks(file);
                const text = yield* fs.readFileString(file);
                const manifest = yield* Effect.try({
                    catch: (error) => new Error(`Cannot inspect pack ${file}: ${String(error)}`),
                    try: () => parseManifest(JSON.parse(text))
                });
                if (manifest.kind !== kind) {
                    return yield* Effect.fail(new Error(`Installed pack is in the wrong directory: ${file}`));
                }
                for (const script of manifest.scripts) {
                    const entry = yield* Effect.try({
                        catch: (error) => new Error(String(error)), try: () => portableName(script)
                    });
                    const target = path.join(location, ...entry.split("/"));
                    yield* rejectLinks(target);
                    if (entry !== script || (yield* fs.stat(target)).type !== "File") {
                        return yield* Effect.fail(new Error(`Invalid installed script entry: ${target}`));
                    }
                }
                for (const id of [manifest.uuid, ...manifest.moduleUuids]) {
                    if (seen.has(id)) {
                        return yield* Effect.fail(new Error(`Duplicate installed UUID: ${id}`));
                    }
                    seen.add(id);
                }
                packs.push({ location, manifest, world });
            }
        }
    }
    return packs;
});
export { scanInstalled };
