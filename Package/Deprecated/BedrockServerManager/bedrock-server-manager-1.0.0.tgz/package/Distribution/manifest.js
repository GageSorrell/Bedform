/**
 * Stable manifest parsing without discarding extension fields.
 *
 * @file manifest.ts
 */
const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const uuid = (value) => typeof value === "string" &&
    /^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(value);
const semver = (value) => {
    const match = /^(\d+)\.(\d+)\.(\d+)(?:-([\da-z.-]+))?(?:\+([\da-z.-]+))?$/i.exec(value);
    if (!match || !match.slice(1, 4).every((part) => /^(0|[1-9]\d*)$/.test(part))) {
        return false;
    }
    const prerelease = match[4]?.split(".") ?? [];
    const build = match[5]?.split(".") ?? [];
    return prerelease.every((part) => /^(0|[1-9]\d*|\d*[a-z-][\da-z-]*)$/i.test(part)) &&
        build.every((part) => /^[\da-z-]+$/i.test(part));
};
const version = (value) => (Array.isArray(value) && value.length === 3 &&
    value.every((part) => typeof part === "number" &&
        Number.isSafeInteger(part) && part >= 0)) ||
    (typeof value === "string" && semver(value));
const versionText = (value) => Array.isArray(value) ? value.join(".") : value;
const sameVersion = (left, right) => versionText(left) === versionText(right);
/**
 * Validate supported manifest fields; errors explain what must be repaired.
 *
 * @throws {Error} When a required field or supported module declaration is invalid.
 */
const parseManifest = (raw) => {
    if (!object(raw)) {
        throw new Error("Manifest must be a JSON object.");
    }
    if (raw.format_version !== 2) {
        throw new Error("Unsupported manifest format; expected format_version 2.");
    }
    const header = raw.header;
    if (!object(header) || typeof header.name !== "string" || !header.name.trim() ||
        !uuid(header.uuid) || !version(header.version)) {
        throw new Error("Manifest header requires a nonempty name, UUID and valid version.");
    }
    if (typeof header.description !== "string" || !version(header.min_engine_version)) {
        throw new Error("Manifest header requires description and a valid min_engine_version.");
    }
    if (!Array.isArray(raw.modules) || !raw.modules.length) {
        throw new Error("Manifest requires at least one module.");
    }
    const kinds = new Set();
    const moduleUuids = [];
    const scripts = [];
    for (const module of raw.modules) {
        if (!object(module) || !uuid(module.uuid) || !version(module.version)) {
            throw new Error("Each module requires a UUID and valid version.");
        }
        const id = module.uuid.toLowerCase();
        if (id === header.uuid.toLowerCase() || moduleUuids.includes(id)) {
            throw new Error(`Duplicate module/header UUID: ${id}`);
        }
        moduleUuids.push(id);
        if (module.type === "resources") {
            kinds.add("resource");
        }
        else if (module.type === "data" || module.type === "script") {
            kinds.add("behavior");
        }
        else {
            throw new Error(`Unsupported pack module kind: ${String(module.type)}`);
        }
        if (module.type === "script") {
            if (module.language !== "javascript" || typeof module.entry !== "string" || !module.entry.trim()) {
                throw new Error("Script modules require language javascript and a nonempty entry path.");
            }
            scripts.push(module.entry);
        }
    }
    if (kinds.size !== 1) {
        throw new Error("A pack cannot mix resource and behavior modules.");
    }
    if (raw.dependencies !== undefined && !Array.isArray(raw.dependencies)) {
        throw new Error("Manifest dependencies must be an array.");
    }
    const dependencies = [];
    for (const dependency of (raw.dependencies ?? [])) {
        if (!object(dependency) || !version(dependency.version) ||
            (uuid(dependency.uuid) === (typeof dependency.module_name === "string" &&
                dependency.module_name.trim().length > 0)) ||
            (dependency.uuid !== undefined && dependency.module_name !== undefined)) {
            throw new Error("Each dependency requires exactly one UUID or module_name and a valid version.");
        }
        dependencies.push(dependency.uuid !== undefined
            ? { uuid: String(dependency.uuid).toLowerCase(), version: dependency.version }
            : { module_name: String(dependency.module_name), version: dependency.version });
    }
    return {
        dependencies, kind: kinds.has("resource") ? "resource" : "behavior",
        moduleUuids, name: header.name, raw, scripts,
        uuid: header.uuid.toLowerCase(), version: header.version
    };
};
export { object, parseManifest, sameVersion, uuid, version, versionText };
