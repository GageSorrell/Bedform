/**
 * Preflight and activation rewrites for bundle replacement/removal in every affected world.
 *
 * @file world-change.ts
 */
import { Effect, FileSystem, Path } from "effect";
import { sameVersion, version, versionText } from "./manifest.js";
import { activationEntries } from "./activation.js";
/** Validate activation against an exact snapshot of packs visible in a world. */
const checkReferences = (packs, behavior, resource) => Effect.gen(function* () {
    const active = new Set();
    const byId = new Map(packs.map((pack) => [pack.manifest.uuid, pack]));
    if (byId.size !== packs.length) {
        return yield* Effect.fail(new Error("Ambiguous duplicate pack identities in affected world."));
    }
    for (const [kind, entries] of [["behavior", behavior], ["resource", resource]]) {
        for (const entry of entries) {
            const id = String(entry.pack_id).toLowerCase();
            const pack = byId.get(id);
            if (active.has(id) || !pack || pack.manifest.kind !== kind || !version(entry.version) ||
                !sameVersion(pack.manifest.version, entry.version)) {
                return yield* Effect.fail(new Error(`Invalid/duplicate ${kind} activation: ${id}`));
            }
            active.add(id);
        }
    }
    return { active, byId };
});
/** Build all world replacements before allowing the enclosing transaction to commit. */
const planWorldChanges = (transaction, worlds, before, after, removed, added, removing) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const changes = [];
    const requirements = new Set();
    for (let index = 0; index < worlds.length; index++) {
        const world = worlds[index];
        const visible = (pack) => pack.world === null || pack.world === world.name;
        const oldPacks = before.filter(visible);
        const newPacks = after.filter(visible);
        const behaviorFile = path.join(world.directory, "world_behavior_packs.json");
        const resourceFile = path.join(world.directory, "world_resource_packs.json");
        const behavior = yield* activationEntries(transaction.server, behaviorFile);
        const resource = yield* activationEntries(transaction.server, resourceFile);
        const original = yield* checkReferences(oldPacks, behavior, resource);
        const byId = new Map(newPacks.map((pack) => [pack.manifest.uuid, pack]));
        if (removing) {
            for (const id of original.active) {
                if (removed.has(id)) {
                    continue;
                }
                const pack = original.byId.get(id);
                for (const dependency of pack.manifest.dependencies) {
                    if (dependency.uuid && removed.has(dependency.uuid)) {
                        return yield* Effect.fail(new Error(`Cannot remove in world ${world.name}: enabled pack ${pack.manifest.name} ` +
                            `(${id}) requires ${dependency.uuid}.`));
                    }
                }
            }
        }
        const next = { behavior: [], resource: [] };
        const active = new Set();
        let bundleEnabled = false;
        for (const [kind, entries] of [["behavior", behavior], ["resource", resource]]) {
            for (const entry of entries) {
                const id = String(entry.pack_id).toLowerCase();
                if (!removed.has(id)) {
                    next[kind].push(entry);
                    active.add(id);
                    continue;
                }
                bundleEnabled = true;
                const replacement = byId.get(id);
                if (!removing && replacement && added.has(id)) {
                    next[replacement.manifest.kind].push({ ...entry, version: replacement.manifest.version });
                    active.add(id);
                }
            }
        }
        const pending = new Set();
        if (!removing && bundleEnabled) {
            for (const id of added) {
                // Retained disabled members stay disabled unless required by an enabled member.
                if (active.has(id) || !removed.has(id)) {
                    pending.add(id);
                }
            }
            // Preserve the bundle's enabled state when none of its formerly enabled members survive.
            if (!pending.size) {
                for (const id of added) {
                    pending.add(id);
                }
            }
        }
        for (const id of pending) {
            const pack = byId.get(id);
            if (!pack) {
                return yield* Effect.fail(new Error(`Updated pack ${id} is unavailable in ${world.name}.`));
            }
            if (!active.has(id)) {
                next[pack.manifest.kind].push({ pack_id: id, version: pack.manifest.version });
                active.add(id);
            }
            for (const dependency of pack.manifest.dependencies) {
                if (dependency.module_name) {
                    requirements.add(`${dependency.module_name}@${versionText(dependency.version)}`);
                    continue;
                }
                const required = byId.get(dependency.uuid);
                if (!required || !sameVersion(required.manifest.version, dependency.version)) {
                    return yield* Effect.fail(new Error(`Missing/mismatched dependency ${dependency.uuid} in world ${world.name}.`));
                }
                pending.add(required.manifest.uuid);
            }
        }
        // External enabled packs must still resolve against the replacement inventory.
        for (const id of active) {
            const pack = byId.get(id);
            for (const dependency of pack.manifest.dependencies) {
                if (!dependency.uuid) {
                    continue;
                }
                const required = byId.get(dependency.uuid);
                if (!required || !active.has(dependency.uuid) ||
                    !sameVersion(required.manifest.version, dependency.version)) {
                    return yield* Effect.fail(new Error(`Update/removal would break enabled dependency ${dependency.uuid} ` +
                        `required by ${pack.manifest.name} in world ${world.name}.`));
                }
            }
        }
        yield* checkReferences(newPacks, next.behavior, next.resource);
        for (const [kind, previous, destination] of [
            ["behavior", behavior, behaviorFile], ["resource", resource, resourceFile]
        ]) {
            if (JSON.stringify(previous) === JSON.stringify(next[kind])) {
                continue;
            }
            const staged = path.join(transaction.stage, `world-${index}-${kind}.new.json`);
            yield* fs.writeFileString(staged, `${JSON.stringify(next[kind], null, 2)}\n`);
            changes.push({ destination, staged });
        }
    }
    return { changes, requirements: [...requirements] };
});
export { planWorldChanges };
