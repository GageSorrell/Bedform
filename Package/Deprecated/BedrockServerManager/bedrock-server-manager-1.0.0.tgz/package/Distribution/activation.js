import { Effect, FileSystem, Path } from "effect";
import { discoverInventory, selectAddon } from "./inventory.js";
import { object, sameVersion, uuid, version, versionText } from "./manifest.js";
import { resolveServer, resolveWorld } from "./server.js";
import { mutationPath } from "./safety.js";
import { scanInstalled } from "./installed.js";
import { withTransaction } from "./transaction.js";
const activationEntries = (server, file) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    yield* mutationPath(server, file);
    if (!(yield* fs.exists(file))) {
        return [];
    }
    const text = yield* fs.readFileString(file);
    return yield* Effect.try({
        catch: (error) => new Error(`Invalid activation file ${file}: ${String(error)}`),
        try: () => {
            const raw = JSON.parse(text);
            if (!Array.isArray(raw)) {
                throw new Error("Expected an activation array.");
            }
            for (const entry of raw) {
                if (!object(entry) || !uuid(entry.pack_id) || !version(entry.version)) {
                    throw new Error("Each activation entry needs pack_id and a valid version.");
                }
            }
            return raw;
        }
    });
});
/** Plan both world files before committing any pack, registry or activation changes. */
const planActivation = (transaction, world, installed, target, enable) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const byId = new Map(installed.map((pack) => [pack.manifest.uuid, pack]));
    if (byId.size !== installed.length) {
        return yield* Effect.fail(new Error("Ambiguous duplicate installed pack identities."));
    }
    const behaviorFile = path.join(world, "world_behavior_packs.json");
    const resourceFile = path.join(world, "world_resource_packs.json");
    const behavior = yield* activationEntries(transaction.server, behaviorFile);
    const resource = yield* activationEntries(transaction.server, resourceFile);
    const active = new Set();
    for (const [kind, entries] of [["behavior", behavior], ["resource", resource]]) {
        for (const entry of entries) {
            const id = String(entry.pack_id).toLowerCase();
            const pack = byId.get(id);
            if (active.has(id) || !pack || pack.manifest.kind !== kind || !version(entry.version) ||
                !sameVersion(pack.manifest.version, entry.version)) {
                return yield* Effect.fail(new Error(`Invalid/duplicate ${kind} activation reference: ${id}`));
            }
            active.add(id);
        }
    }
    const desired = new Set(target);
    const requirements = new Set();
    for (const id of desired) {
        if (!byId.has(id)) {
            return yield* Effect.fail(new Error(`Target pack is not installed: ${id}`));
        }
    }
    if (enable) {
        // Set iteration visits appended dependencies once and naturally accepts cycles.
        for (const id of desired) {
            const pack = byId.get(id);
            for (const dependency of pack.manifest.dependencies) {
                if (dependency.module_name) {
                    requirements.add(`${dependency.module_name}@${versionText(dependency.version)}`);
                    continue;
                }
                const required = byId.get(dependency.uuid);
                if (!required || !sameVersion(required.manifest.version, dependency.version)) {
                    return yield* Effect.fail(new Error(`Missing/mismatched dependency ${dependency.uuid}` +
                        `@${versionText(dependency.version)} ` +
                        `required by ${pack.manifest.name}.`));
                }
                desired.add(required.manifest.uuid);
            }
        }
    }
    else {
        for (const id of active) {
            if (desired.has(id)) {
                continue;
            }
            const dependent = byId.get(id);
            if (dependent.manifest.dependencies.some((dependency) => dependency.uuid && desired.has(dependency.uuid))) {
                return yield* Effect.fail(new Error(`Cannot disable: enabled pack ${dependent.manifest.name} (${id}) requires this addon.`));
            }
        }
    }
    const changes = [];
    for (const [kind, entries, destination] of [
        ["behavior", behavior, behaviorFile], ["resource", resource, resourceFile]
    ]) {
        const next = enable ? [...entries] : entries.filter((entry) => !desired.has(String(entry.pack_id).toLowerCase()));
        if (enable) {
            for (const id of desired) {
                const pack = byId.get(id);
                if (pack.manifest.kind === kind && !active.has(id)) {
                    next.push({ pack_id: id, version: pack.manifest.version });
                }
            }
        }
        if (JSON.stringify(next) === JSON.stringify(entries)) {
            continue;
        }
        const staged = path.join(transaction.stage, `world-${kind}.new.json`);
        yield* fs.writeFileString(staged, `${JSON.stringify(next, null, 2)}\n`);
        changes.push({ destination, staged });
    }
    return { changes, requirements: [...requirements] };
});
const changeActivation = (context, selector, options, enable) => Effect.gen(function* () {
    const server = yield* resolveServer(context, options.server);
    const world = yield* resolveWorld(context, server, options.world);
    return yield* withTransaction(server, (transaction) => Effect.gen(function* () {
        const path = yield* Path.Path;
        yield* mutationPath(server, path.join(server, ".bedrock-server-manager", "registry.json"));
        const inventory = yield* discoverInventory(context, { ...options, server, world: world.name });
        const addon = yield* selectAddon(inventory, selector, options.scope);
        if (!addon.members.length || addon.members.some((pack) => !pack.identity) ||
            inventory.diagnostics.some((entry) => entry.code === "missing-registered-pack" &&
                entry.message.startsWith(`Bundle ${addon.id} `))) {
            return yield* Effect.fail(new Error(`Bundle ${addon.id} has missing or invalid packs.`));
        }
        const all = yield* scanInstalled(server);
        const selected = all.filter((pack) => pack.world === null || pack.world === world.name);
        const planned = yield* planActivation(transaction, world.directory, selected, addon.members.map((pack) => pack.identity.uuid), enable);
        yield* transaction.commit(planned.changes);
        return { id: addon.id, name: addon.name, requirements: planned.requirements };
    }));
});
export { activationEntries, changeActivation, planActivation };
