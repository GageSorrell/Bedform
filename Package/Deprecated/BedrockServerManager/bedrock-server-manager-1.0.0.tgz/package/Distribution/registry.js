/**
 * Versioned bundle registry contract. Read-only commands never create this file.
 *
 * @file registry.ts
 */
import { Effect, FileSystem, Path } from "effect";
import { object, uuid } from "./manifest.js";
const parseRegistry = (raw) => Effect.gen(function* () {
    const path = yield* Path.Path;
    return yield* Effect.try({
        catch: (error) => new Error(`Invalid bundle registry: ${String(error)}`),
        try: () => {
            if (!object(raw) || raw.version !== 1 || !Array.isArray(raw.bundles)) {
                throw new Error("Expected version 1 and a bundles array.");
            }
            const ids = new Set();
            const locations = new Set();
            const owners = new Map();
            const bundles = [];
            for (const entry of raw.bundles) {
                if (!object(entry) || typeof entry.id !== "string" || !entry.id.trim() ||
                    ids.has(entry.id) ||
                    typeof entry.name !== "string" || !entry.name.trim() ||
                    !(entry.source === null || (typeof entry.source === "string" &&
                        path.isAbsolute(entry.source))) || !Array.isArray(entry.packs) || !entry.packs.length) {
                    throw new Error("Bundles need a unique ID, name, absolute source (or null) and members.");
                }
                ids.add(entry.id);
                const packs = [];
                for (const member of entry.packs) {
                    if (!object(member) || !uuid(member.uuid) || typeof member.location !== "string" ||
                        !/^(?:worlds\/[^/]+\/)?(?:behavior_packs|resource_packs)\/[^/]+$/
                            .test(member.location) ||
                        /[\\:\0]/.test(member.location) || member.location.split("/").some((part) => part === "." || part === "..")) {
                        throw new Error("Members need a UUID and a safe server-relative pack location.");
                    }
                    const locationKey = path.normalize(member.location);
                    const normalized = path.sep === "\\" ? locationKey.toLowerCase() : locationKey;
                    const id = member.uuid.toLowerCase();
                    if (locations.has(normalized) || (owners.has(id) && owners.get(id) !== entry.id)) {
                        throw new Error(`Conflicting member ownership: ${member.location} (${id})`);
                    }
                    locations.add(normalized);
                    owners.set(id, entry.id);
                    packs.push({ location: member.location, uuid: id });
                }
                bundles.push({ id: entry.id, name: entry.name, packs, source: entry.source });
            }
            return { bundles, version: 1 };
        }
    });
});
const readRegistry = (server) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const file = path.join(server, ".bedrock-server-manager", "registry.json");
    if (!(yield* fs.exists(file))) {
        return { bundles: [], version: 1 };
    }
    const content = yield* fs.readFileString(file);
    const raw = yield* Effect.try({
        catch: (error) => new Error(`Invalid bundle registry at ${file}: ${String(error)}`),
        try: () => JSON.parse(content)
    });
    return yield* parseRegistry(raw);
});
export { parseRegistry, readRegistry };
