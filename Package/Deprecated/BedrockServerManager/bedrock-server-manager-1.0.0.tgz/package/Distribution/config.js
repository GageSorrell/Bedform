/**
 * User configuration and safe persistence.
 *
 * @file config.ts
 */
import { Effect, FileSystem, Path } from "effect";
const isObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
/** Resolve the user configuration file without touching the filesystem. */
const configPath = (context) => Effect.gen(function* () {
    const path = yield* Path.Path;
    const override = context.env.BDS_CONFIG_PATH;
    if (override !== undefined) {
        if (!override.trim()) {
            return yield* Effect.fail(new Error("BDS_CONFIG_PATH must not be empty."));
        }
        return path.resolve(context.cwd, override);
    }
    let base;
    if (context.platform === "win32") {
        if (!context.env.APPDATA) {
            return yield* Effect.fail(new Error("APPDATA is missing; set BDS_CONFIG_PATH explicitly."));
        }
        base = context.env.APPDATA;
    }
    else if (context.platform === "darwin") {
        base = path.join(context.home, "Library", "Application Support");
    }
    else {
        base = context.env.XDG_CONFIG_HOME || path.join(context.home, ".config");
    }
    return path.resolve(context.cwd, base, "bedrock-server-manager", "config.json");
});
/** Read and validate existing settings, without creating a missing file. */
const readSettings = (context) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const file = yield* configPath(context);
    if (!(yield* fs.exists(file))) {
        return {};
    }
    const content = yield* fs.readFileString(file);
    return yield* Effect.try({
        catch: (error) => new Error(`Invalid configuration at ${file}: ${String(error)}`),
        try: () => {
            const value = JSON.parse(content);
            if (!isObject(value) || (value.server !== undefined && !isObject(value.server))) {
                throw new Error("Expected a settings object with an optional server object.");
            }
            if (isObject(value.server) && value.server.path !== undefined &&
                (typeof value.server.path !== "string" || !value.server.path.trim())) {
                throw new Error("server.path must be a nonempty string.");
            }
            return value;
        }
    });
});
/** Reject unregistered keys before touching settings. */
const validateKey = (key) => key === "server.path"
    ? Effect.void
    : Effect.fail(new Error(`Unsupported setting "${key}". Supported keys: server.path.`));
/** Require an existing directory and return its absolute path. */
const requireDirectory = (value, context) => Effect.gen(function* () {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    if (!value.trim()) {
        return yield* Effect.fail(new Error("Directory path must not be empty."));
    }
    const absolute = path.resolve(context.cwd, value);
    const info = yield* fs.stat(absolute).pipe(Effect.mapError(() => new Error(`Cannot access directory "${absolute}". Choose an existing directory.`)));
    if (info.type !== "Directory") {
        return yield* Effect.fail(new Error(`Expected a directory: ${absolute}`));
    }
    return absolute;
});
/** Persist a setting through a same-filesystem temporary file replacement. */
const writeSetting = (context, key, value) => Effect.gen(function* () {
    yield* validateKey(key);
    const settings = yield* readSettings(context);
    const absolute = value === undefined ? undefined : yield* requireDirectory(value, context);
    const server = { ...settings.server };
    if (absolute === undefined) {
        delete server.path;
    }
    else {
        server.path = absolute;
    }
    if (Object.keys(server).length) {
        settings.server = server;
    }
    else {
        delete settings.server;
    }
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const file = yield* configPath(context);
    yield* fs.makeDirectory(path.dirname(file), { recursive: true });
    yield* Effect.scoped(Effect.gen(function* () {
        const temporary = yield* fs.makeTempDirectoryScoped({
            directory: path.dirname(file), prefix: ".bds-"
        });
        const staged = path.join(temporary, "config.json");
        yield* fs.writeFileString(staged, `${JSON.stringify(settings, null, 2)}\n`, { mode: 0o600 });
        yield* fs.rename(staged, file);
    }));
});
export { configPath, readSettings, requireDirectory, validateKey, writeSetting };
